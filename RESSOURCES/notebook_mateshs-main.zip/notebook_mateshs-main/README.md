#  Le notebook et la programmation lettrée  [<img src="figure/Rzine.png"  align="right" width="120"/>](http://rzine.fr/)
## Documenter ses traitements 

*Diaporama utilisé lors des Journées annuelles MATE-SHS 2022*

[Afficher les slides](https://huguespecout.github.io/notebook_mateshs/)
