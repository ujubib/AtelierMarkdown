# Mon premier Markdown

![](https://gapn.hypotheses.org/files/2020/10/mate-300x61.jpg)

## Journées annuelles 2022 :satisfied:

-> Consultez [**le programme**](https://ja-mate2022.sciencesconf.org/resource/page/id/1) !

### A. Interventions pévues

1. *Le notebook et la programmation lettrée*
    - Notebook ?
    - Historique
    - Dernière génération
    - Notebook + Git
    - Exemple Quarto
    
3. *Le projet Rzine*
    - Le *projet Rzine*
    - Le [*site web*](rzine.fr)
    - La *collection*
    
### B. Intervenants

| Nom    | Prénom      | 
| ------ | ----------- |
| Giraud | Timothée    |
| Pecout | Hugues      | 
| Rey    | Sébastien   |


> Le texte brut balisé en Markdown reste lisible pour l'humain, se stocke dans un simple fichier texte et de nombreux outils libres permettent de l'éditer.




